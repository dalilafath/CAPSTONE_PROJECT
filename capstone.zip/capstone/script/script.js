const button = document.querySelector('.button');

button.addEventListener('click', function() {
    alert('Welcome to the application!');
});
